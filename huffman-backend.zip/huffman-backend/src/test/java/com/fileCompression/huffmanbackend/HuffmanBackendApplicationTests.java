package com.fileCompression.huffmanbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HuffmanBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
